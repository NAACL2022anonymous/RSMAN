from .modeling_bert import BertForDocRED
